import processing.core.PImage;

import java.util.List;

public class House extends Entity {

    public House(WorldModel world, ImageStore imageStore, int repeatCount, String id, Point position, List<PImage> images) {
        super(world, imageStore, repeatCount, id, position, images);

    }

}
