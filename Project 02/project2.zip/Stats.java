public class Stats extends Entity {
}
